import dynamic from 'dva/dynamic';
export const AddComponent = (app, config) => {
    return dynamic({
        app,
        models: () => config.models, // 此处可以导入多个模块
        component: () => config.component // 页面
    });
};
