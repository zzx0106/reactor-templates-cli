'use strict';
import dva from 'dva';
import dvaLoading from 'dva-loading'; //loading控件
import router from './routers/router'; // 引入路由文件
import imgLog from 'img-log';
imgLog(require('assets/images/logo_g.gif'), 50);
const app = dva();
app.use(dvaLoading()); // 加载loading控件
app.router(router); // 加载路由
// app.model(models); // 模块在路由中引入，所以无需这个
app.start('#app'); // 挂载到html的root
