import dynamic from 'dva/dynamic';
// 异步组件
const DemoComponent = app => {
    return dynamic({
        app,
        // 建议用@开头的路径
        models: () => [import('@/pages/Demo/models/demo_model')], // 此处可以导入多个模块
        component: () => import('@/pages/Demo') // 页面
    });
};
export default DemoComponent;
