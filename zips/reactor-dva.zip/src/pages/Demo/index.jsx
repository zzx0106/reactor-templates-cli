import React, { Component } from 'react';
// import { connect } from 'react-redux';
import { connect } from 'dva';
import PropTypes from 'prop-types';
import 'assets/css/pages/Demo.scss';
// 装饰器
@connect(
    (state, ownProps) => {
        console.log(state);
        return {
            // dva-loding插件，查找对应的异步action，并loding
            loading: state.loading.effects['demo_model/asyncDataAction'],
            // 以模块划分包名
            demoReducer: state.demo_model.toJS() // 将immutable转为js
        };
    },
    (dispatch, ownProps) => {
        return {
            accelerateImg: () => {
                dispatch({
                    type: 'demo_model/accelerate'
                });
            },
            asyncData: () => {
                dispatch({
                    type: 'demo_model/asyncDataAction'
                });
            },
            decelerationImg: () => {
                dispatch({
                    type: 'demo_model/deceleration'
                });
            }
        };
    }
)
class Demo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            count: 0,
            face: 0 // 泡泡标签
        };
        this.t = 0; //旋转圈数
    }
    componentDidMount() {
        this.faceTimer = setInterval(() => {
            if (this.t > 0) {
                if (this.state.face === 10) return;
                this.setState({
                    face: this.state.face + 1
                });
            } else {
                this.setState({
                    face: 0
                });
            }
        }, 3000);
    }
    componentWillUnmount() {
        window.clearInterval(this.faceTimer);
        this.faceTimer = null;
    }
    rotateBox = () => {
        let i = 0;
        this.animate_start = true;
        const rotate = () => {
            i += 2.5;
            // 这个写法是避免dva-hmr导致this.icon_img暂时获取不到的问题
            this.icon_img ? this.icon_img.style.transform = `rotate3d(0,0,1,${i}deg)` : null;
            if (this.t <= 0) {
                this.t = 0;
                i = 0;
                window.cancelAnimationFrame(this.RAF);
                this.animate_start = false;
            }
            if (i >= 365) {
                i = 0;
                this.props.decelerationImg(); // -一次
            }
            if (this.animate_start) this.RAF = window.requestAnimationFrame(rotate);
        };
        this.RAF = window.requestAnimationFrame(rotate);
    };
    addRotateNumber = num => {
        this.t = num;
        if (!this.animate_start && num > 0) {
            this.rotateBox();
        }
    };
    render() {
        const { face } = this.state;
        const { accelerateImg, asyncData, decelerationImg, demoReducer, loading } = this.props;
        if (demoReducer.speed >= 0) {
            this.addRotateNumber(demoReducer.speed);
        }
        return (
            <div className="demo-container">
                <span>
                    剩余圈数：
                    {demoReducer.speed}
                </span>
                <div className="icon">
                    <img className="icon-img" ref={imgdom => (this.icon_img = imgdom)} src={require(`assets/images/demo/${face < 10 ? '0' + face : face + ''}.png`)} alt="" />
                </div>
                <div className="title">
                    {loading && !demoReducer.message ? <img width="130px" src={require('assets/images/loading.svg')} alt="" /> : null}
                    <p>{demoReducer.message}</p>
                </div>
                <div className="btn-box">
                    <button className="btn-success" onClick={decelerationImg}>
                        减一圈
                    </button>{' '}
                    -----
                    <button className="btn-info" onClick={asyncData}>
                        异步数据
                    </button>
                    -----
                    <button className="btn-primary" onClick={accelerateImg}>
                        加一圈
                    </button>
                </div>
            </div>
        );
    }
}
Demo.propTypes = {
    demoReducer: PropTypes.object
};
export default Demo;
