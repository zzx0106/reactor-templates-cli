import Immutable from 'immutable';
export default {
    namespace: 'demo_model', // 命名空间
    state: Immutable.fromJS({
        speed: 0,
        message: ''
    }),
    reducers: {
        accelerate(state, action) {
            return state.update('speed', val => val + 1); // 更新
        },
        deceleration(state, action) {
            return state.update('speed', val => (val - 1 < 0 ? 0 : val - 1)); // 更新
        },
        fetchError(state, action) {
            return state.set('message', '报错了'); // 更新
        },
        fetchSuccess(state, action) {
            return state.merge({
                message: action.payload.data
            });
        }
    },
    effects: {
        // saga的effects，在里面可以执行异步操作
        *asyncDataAction(action, { put, call }) {
            const sleep = time => {
                return new Promise((resolve, reject) => {
                    setTimeout(() => {
                        resolve({
                            data: '欢迎使用reactor'
                        });
                    }, time);
                });
            };
            const message = yield call(sleep, 3000);
            if (!message) yield put({ type: 'fetchError' });
            yield put({ type: 'fetchSuccess', payload: message });
        }
    },
    subscriptions: {
        // 当页面使用了此模块，模块挂在完毕后就会执行该对象中的方法
        onload({ dispatch, history }) {
            // 传递了路由，可以跳转，可以做鉴权
            console.log('subscriptions');
        }
    }
};
