import dynamic from 'dva/dynamic';
const AddComponent = app => {
    return dynamic({
        app,
        models: () => [], // 此处可以导入多个模块
        component: () => import('@/pages/Home') // 页面 建议用@开头的路径
    });
};
export default AddComponent;
