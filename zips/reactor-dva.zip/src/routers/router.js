import React from 'react';
import { Router, Route, Switch } from 'dva/router';

// import Home from 'bundle-loader?lazy&name=home!pages/Home/Home';
import Home from '../pages/Home/router'; // 在webpack中配置了bundle-loader
import Demo from '@/pages/Demo/router'; // 在webpack中配置了bundle-loader

const getRouter = ({ history, app }) => {
    return (
        <Router history={history}>
            <Switch>
                <Route exact path="/" component={Home(app)} />
                <Route path="/demo" component={Demo(app)} />
            </Switch>
        </Router>
    );
};

export default getRouter;
