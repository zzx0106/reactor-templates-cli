import demoReducer from './demoReducer';
import { combineReducers } from 'redux';
export default combineReducers({
    demoReducer,
})
