const Type = {
    FETCH_START: 'FETCH_START',
    FETCH_ERR: 'FETCH_ERR',
    FETCH_SUCCESS: 'FETCH_SUCCESS'
};
export default Type;
