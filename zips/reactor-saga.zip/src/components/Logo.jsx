import React, { Component } from 'react';
import 'assets/css/components/Logo.scss';
export default class Logo extends Component {
    render() {
        return (
            <div className="logo-box">
                <div className="logo" />
            </div>
        );
    }
}
